import React, { useState } from 'react';

const Calculator: React.FC = () => {
  const [display, setDisplay] = useState('0');
  const [operand, setOperand] = useState<number | null>(null);
  const [operator, setOperator] = useState<string | null>(null);
  const [isNewEntry, setIsNewEntry] = useState(true);

  const handleDigitClick = (digit: string) => {
    if (isNewEntry) {
      setDisplay(digit);
      setIsNewEntry(false);
    } else {
      setDisplay(display === '0' ? digit : display + digit);
    }
  };

  const handleDecimal = () => {
    if (isNewEntry) {
      setDisplay('0.');
      setIsNewEntry(false);
    } else if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  };

  const handleOperator = (op: string) => {
    if (operator && !isNewEntry) {
      handleEquals();
    }
    setOperand(parseFloat(display));
    setOperator(op);
    setIsNewEntry(true);
  };

  const handleEquals = () => {
    const currentOperand = parseFloat(display);
    if (operator && operand !== null) {
      let result = 0;
      if (operator === '+') result = operand + currentOperand;
      else if (operator === '-') result = operand - currentOperand;
      else if (operator === '*') result = operand * currentOperand;
      else if (operator === '/') result = operand / currentOperand;
      setDisplay(String(result));
      setOperand(null);
      setOperator(null);
      setIsNewEntry(true);
    }
  };

  const handleClear = () => {
    setDisplay('0');
    setOperand(null);
    setOperator(null);
    setIsNewEntry(true);
  };
  
  const handleSignChange = () => {
    setDisplay(String(parseFloat(display) * -1));
  };
  
  const handlePercentage = () => {
    setDisplay(String(parseFloat(display) / 100));
  };

  const buttonClasses = "rounded text-xl font-semibold transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500";
  const numButtonClasses = "bg-white hover:bg-gray-100 text-black border border-gray-300";
  const opButtonClasses = "bg-blue-500 hover:bg-blue-600 text-white";
  const specialButtonClasses = "bg-gray-300 hover:bg-gray-400 text-black";

  const buttons = [
    { label: 'AC', handler: handleClear, style: specialButtonClasses },
    { label: '+/-', handler: handleSignChange, style: specialButtonClasses },
    { label: '%', handler: handlePercentage, style: specialButtonClasses },
    { label: '/', handler: () => handleOperator('/'), style: opButtonClasses },
    { label: '7', handler: () => handleDigitClick('7'), style: numButtonClasses },
    { label: '8', handler: () => handleDigitClick('8'), style: numButtonClasses },
    { label: '9', handler: () => handleDigitClick('9'), style: numButtonClasses },
    { label: '*', handler: () => handleOperator('*'), style: opButtonClasses },
    { label: '4', handler: () => handleDigitClick('4'), style: numButtonClasses },
    { label: '5', handler: () => handleDigitClick('5'), style: numButtonClasses },
    { label: '6', handler: () => handleDigitClick('6'), style: numButtonClasses },
    { label: '-', handler: () => handleOperator('-'), style: opButtonClasses },
    { label: '1', handler: () => handleDigitClick('1'), style: numButtonClasses },
    { label: '2', handler: () => handleDigitClick('2'), style: numButtonClasses },
    { label: '3', handler: () => handleDigitClick('3'), style: numButtonClasses },
    { label: '+', handler: () => handleOperator('+'), style: opButtonClasses },
    { label: '0', handler: () => handleDigitClick('0'), style: `${numButtonClasses} col-span-2` },
    { label: '.', handler: handleDecimal, style: numButtonClasses },
    { label: '=', handler: handleEquals, style: opButtonClasses },
  ];

  return (
    <div className="w-full max-w-xs mx-auto p-4 bg-gray-200 rounded-lg">
      <div className="bg-white text-black text-4xl text-right p-3 rounded mb-4 overflow-x-auto border border-gray-300">
        {display}
      </div>
      <div className="grid grid-cols-4 gap-3">
        {buttons.map(btn => (
          <button key={btn.label} onClick={btn.handler} className={`${buttonClasses} ${btn.style} py-4`}>
            {btn.label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default Calculator;