import React, { useState } from 'react';
import { ActiveTool } from './types';
import Calculator from './components/Calculator';
import CgpaCalculator from './components/CgpaCalculator';
import MatrixCalculator from './components/MatrixCalculator';
import TabButton from './components/TabButton';

const App: React.FC = () => {
  const [activeTool, setActiveTool] = useState<ActiveTool>(ActiveTool.Calculator);

  const renderTool = () => {
    switch (activeTool) {
      case ActiveTool.Calculator:
        return <Calculator />;
      case ActiveTool.CgpaCalculator:
        return <CgpaCalculator />;
      case ActiveTool.MatrixCalculator:
        return <MatrixCalculator />;
      default:
        return <Calculator />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 text-gray-800 flex flex-col items-center p-4 font-sans">
      <header className="w-full max-w-4xl text-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Multi-Tool Calculator</h1>
        
      </header>

      <div className="w-full max-w-4xl bg-white rounded-lg shadow-md border border-gray-200 overflow-hidden">
        <nav className="flex bg-gray-200">
          {Object.values(ActiveTool).map((tool) => (
            <TabButton
              key={tool}
              label={tool}
              isActive={activeTool === tool}
              onClick={() => setActiveTool(tool)}
            />
          ))}
        </nav>
        <main className="p-4 sm:p-6 md:p-8">
          {renderTool()}
        </main>
      </div>

      
    </div>
  );
};

export default App;